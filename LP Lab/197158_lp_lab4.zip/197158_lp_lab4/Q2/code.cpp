int main(){
	
	int a;

}
